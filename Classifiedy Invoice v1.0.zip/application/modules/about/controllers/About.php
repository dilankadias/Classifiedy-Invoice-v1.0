<?php

if ( ! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

#[AllowDynamicProperties]
class About extends Admin_Controller
{
    public function index()
    {
        $this->layout->buffer('content', 'about/index');
        $this->layout->render();
    }
}
