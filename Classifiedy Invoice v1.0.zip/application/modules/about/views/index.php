<section class="ip-about" aria-labelledby="about-title">
    <div class="ip-about-hero">
        <img src="<?php echo base_url(); ?>assets/logo.png" alt="Classifiedy">
        <h1 id="about-title">Built To Make Business Simpler</h1>
        <p class="ip-about-lead">
            Classifiedy Invoice is an invoicing and accounting platform built by Classifiedy, a US-based software company helping businesses grow with clarity, confidence, and ease.
        </p>
    </div>

    <div class="ip-about-body">
        <h2>Our Story</h2>
        <br>
        <p>
            Classifiedy is a US-based company that builds web applications for businesses
            across the United States and Australia. We created Classifiedy Invoice because
            managing invoices, tracking payments, and keeping books in order should not
            require expensive software or an accounting degree.
        </p>
        <p>
            Too many small businesses, freelancers, and growing teams lose hours every week
            to tasks that should take minutes. So we built a platform that is powerful enough
            for scaling operations and simple enough for solo professionals. No clutter.
            No complexity. Just the tools you actually need.
        </p>

        <h2>What We Believe</h2>
        <br>
        <ul style="list-style: none; padding: 0; margin: 0;">
            <li style="margin-bottom: 18px; padding-left: 24px; position: relative;">
                <span style="position: absolute; left: 0; top: 0; color: #1a2a3a; font-weight: bold;">&#10003;</span>
                <strong>Simplicity first.</strong> Good software gets out of your way and lets you focus on your business.
            </li>
            <li style="margin-bottom: 18px; padding-left: 24px; position: relative;">
                <span style="position: absolute; left: 0; top: 0; color: #1a2a3a; font-weight: bold;">&#10003;</span>
                <strong>Built to grow.</strong> Your tools should scale with you, not hold you back.
            </li>
            <li style="margin-bottom: 18px; padding-left: 24px; position: relative;">
                <span style="position: absolute; left: 0; top: 0; color: #1a2a3a; font-weight: bold;">&#10003;</span>
                <strong>Your data stays yours.</strong> Classifiedy Invoice is self-hosted on your own servers. We never access, store, or sell your data.
            </li>
        </ul>

        <h2>What We Do</h2>
        <br>
        <p>
            Classifiedy Invoice helps businesses create professional invoices, track payments,
            manage clients, and understand their finances from one clean dashboard.
            Whether you are sending your first invoice or managing hundreds of accounts,
            the platform adapts to how you work.
        </p>
        <p>
            From our base in the United States, we serve businesses operating across the US
            and Australia, with tools designed to handle multiple currencies, tax systems,
            and payment methods. As your business evolves, Classifiedy Invoice grows with you.
        </p>
    </div>

    <!-- Social Media Links -->
    <div class="ip-about-social" style="display: flex; justify-content: flex-end; margin-top: 20px;">
        <div class="ip-about-social-links" style="display: flex; gap: 20px;">
            <!-- Facebook Link -->
            <a href="https://www.facebook.com/profile.php?id=61559875300382" target="_blank" rel="noopener noreferrer" aria-label="Follow Classifiedy on Facebook">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
            </a>

            <!-- LinkedIn Link -->
            <a href="https://www.linkedin.com/company/classifiedy" target="_blank" rel="noopener noreferrer" aria-label="Follow Classifiedy on LinkedIn">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
            </a>
        </div>
    </div>
</section>