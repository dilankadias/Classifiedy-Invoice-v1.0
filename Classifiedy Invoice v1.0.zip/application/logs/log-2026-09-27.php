<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-09-27 15:03:10 --> Invalid XML config ID detected: .gitignore
ERROR - 2026-09-27 15:03:10 --> Invalid XML config ID detected: README.md
ERROR - 2026-09-27 15:03:57 --> Invalid XML config ID detected: .gitignore
ERROR - 2026-09-27 15:03:57 --> Invalid XML config ID detected: README.md
